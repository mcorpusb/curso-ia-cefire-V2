---
name: generador-gift-aules
description: Crea cuestionarios GIFT para Moodle/Aules desde apuntes docentes, con verdadero/falso y cuatro opciones, una correcta, sin numeracion y con dificultad configurable.
---

# Generador de cuestionarios GIFT para Aules

## Cuándo usar esta habilidad

Utilízala cuando un docente pida crear o revisar un banco de preguntas para Moodle/Aules en formato GIFT, basándose en materiales que facilita en la conversación.

## Fuentes y límites

- Trabaja solamente con los archivos o el texto efectivamente disponibles. Si el usuario menciona un cuaderno o repositorio al que no tienes acceso, solicita que aporte su contenido. No finjas haberlo consultado.
- No introduzcas contenidos ajenos a las fuentes, salvo permiso expreso del docente.
- No proceses datos identificables del alumnado ni documentos sensibles sin la autorización correspondiente.
- Si el material no contiene información suficiente, pide nuevas fuentes antes de inventar preguntas.

## Parámetros

Identifica etapa, curso, materia, tema, cantidad de preguntas (10 por defecto), dificultad (baja, media, alta o muy alta; media por defecto), modalidad (verdadero/falso, opción múltiple o mixta; mixta por defecto), idioma y fuente. Solicita solo lo esencial que falte.

- Baja: reconocer y recordar conceptos.
- Media: comprender y aplicar.
- Alta: analizar y resolver casos.
- Muy alta: razonar sobre situaciones complejas respaldadas por las fuentes.

## Construcción

- Genera exactamente la cantidad de preguntas pedida.
- Si la modalidad es mixta y no se da proporción, reparte las preguntas entre verdadero/falso y opción múltiple de la forma más equilibrada posible.
- Verdadero/falso: afirmaciones claras e inequívocas, equilibrio de verdaderas y falsas cuando sea posible. Utiliza `{T}` o `{F}`.
- Opción múltiple: **exactamente cuatro opciones**, una única correcta precedida por `=`, y tres incorrectas precedidas por `~`. Diversifica la posición de la opción correcta, evita distractores absurdos y comprueba que no exista otra opción válida.
- Cada pregunta debe ser independiente y no revelar la respuesta de otra.
- Incluye retroalimentación breve y respaldada por las fuentes usando sintaxis GIFT válida.
- No crees emparejamiento, respuesta corta ni ensayo, salvo solicitud expresa.

## Identificadores y GIFT

- Usa identificadores **únicos, descriptivos y sin numeración secuencial** como `::VF_RestauracionSistema::` o `::OM_CopiasIncrementales::`.
- No escribas `Q01`, `T3_02`, `Pregunta3` ni números de orden en títulos, enunciados u opciones.
- No escribas letras A, B, C, D delante de las alternativas.
- Escapa los caracteres reservados de GIFT donde corresponda y separa las preguntas con una línea en blanco.
- Comprueba que las llaves, la sintaxis de las opciones y la retroalimentación sean válidas.
- No confundas quitar numeración con barajar: el barajado del cuestionario y sus respuestas debe configurarlo el docente en Aules.

## Entrega

1. Intenta crear un archivo real de **texto plano UTF-8 con extensión `.txt`**, y nombre descriptivo (por ejemplo, `seguridad_pasiva_alta.txt`). El contenido del archivo debe ser **únicamente GIFT**, sin títulos Markdown, envoltorios de código ni explicaciones.
2. Si no puedes crear y adjuntar un `.txt`, dilo explícitamente y entrega un bloque limpio de contenido GIFT que pueda guardarse en un `.txt`. No presentes un `.md` como si fuese un `.txt`.
3. Fuera del archivo, muestra un resumen de los parámetros y un solucionario separado para el docente. Cuando sea posible, identifica qué parte de la fuente sustenta cada respuesta.
4. No afirmes haber validado la importación en Aules a menos que se haya comprobado realmente.

## Lista de control final

- [ ] Cantidad exacta y modalidad pedida.
- [ ] Cuatro opciones y solo una correcta en cada pregunta de opción múltiple.
- [ ] Respuestas y distractores contrastados con las fuentes.
- [ ] Identificadores únicos sin números de orden.
- [ ] Respuestas correctas no siempre en primera posición.
- [ ] Preguntas sin referencias entre sí.
- [ ] GIFT sin Markdown y archivo `.txt` UTF-8, si se ha podido generar.
- [ ] Solucionario separado; revisión final a cargo del docente.
